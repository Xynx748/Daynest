# DayNest starter

A free, offline-first starter app for everyday tasks, notes, and saved links.

## Included
- Add, edit, complete, and delete tasks/notes/links
- Optional due dates and search
- Local persistence using IndexedDB
- JSON export and import backup
- PWA manifest and service-worker cache for offline app-shell use
- Responsive layout for phone and desktop

## Important limitations
- **No cloud sync yet.** Data is stored separately in each browser/device. Use Export backup on one device and Import backup on another to move data manually.
- Browser storage is not a substitute for backups. Export your data regularly and keep the backup somewhere safe.
- Notifications are not included in this first version.
- This is a starter prototype and has not been independently security-audited.

## Run locally on Windows
1. Install Python 3 if it isn't already installed.
2. Extract this ZIP to a folder.
3. Open that folder in File Explorer.
4. Click the address bar, type `cmd`, and press Enter.
5. Run:

   ```bat
   py -m http.server 8000
   ```

6. On the laptop, open `http://localhost:8000`.
7. To test from your phone on the same Wi-Fi, find your laptop's local IPv4 address with `ipconfig`, then open `http://YOUR-LAPTOP-IP:8000` on the phone. Service workers require a secure context, so install/offline PWA support is expected on localhost or HTTPS hosting, not a plain LAN HTTP address.

## Publish free for PWA installation
A static host with HTTPS is needed for installation and service-worker offline support. GitHub Pages can host static files in a public repository for free under GitHub Free. Read:
- https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
- https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Offline_and_background_operation

Once published over HTTPS, open the hosted URL in Chrome on Android or Edge/Chrome on Windows and use the browser's Install/Add to Home Screen option when available.

## Suggested next steps
1. Test add/edit/delete, due dates, search, export, and import.
2. Test offline by opening the hosted app once, then disconnecting the network.
3. Add tests and improve accessibility.
4. Only after the core is reliable, plan optional cloud sync and notifications.
