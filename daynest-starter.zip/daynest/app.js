const DB_NAME = "daynest-db";
const STORE = "items";
let db;
let activeFilter = "inbox";
let deferredInstallPrompt = null;
const $ = (id) => document.getElementById(id);
const labels = { inbox: "All items", today: "Due today", tasks: "Tasks", notes: "Notes", links: "Saved links", completed: "Completed" };

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE)) {
        const store = database.createObjectStore(STORE, { keyPath: "id" });
        store.createIndex("updatedAt", "updatedAt");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
function store(mode = "readonly") { return db.transaction(STORE, mode).objectStore(STORE); }
function getAll() {
  return new Promise((resolve, reject) => {
    const req = store().getAll();
    req.onsuccess = () => resolve(req.result.sort((a,b) => b.updatedAt - a.updatedAt));
    req.onerror = () => reject(req.error);
  });
}
function put(item) {
  return new Promise((resolve, reject) => {
    const req = store("readwrite").put(item);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
function remove(id) {
  return new Promise((resolve, reject) => {
    const req = store("readwrite").delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}
function makeId() { return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`; }
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2600);
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
}
function safeUrl(value) {
  try { const url = new URL(value); return ["http:", "https:"].includes(url.protocol) ? url.href : null; } catch { return null; }
}
function formatDate(date) {
  if (!date) return "";
  const parsed = new Date(`${date}T12:00:00`);
  return Number.isNaN(parsed.getTime()) ? date : parsed.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}
function isToday(date) { return date === new Date().toLocaleDateString("en-CA"); }
function renderDetails(item) {
  const details = item.details || "";
  if (item.type === "link") {
    const url = safeUrl(details) || safeUrl(item.title);
    if (url) return `<div class="item-details"><a href="${escapeHTML(url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(details || url)}</a></div>`;
  }
  return details ? `<div class="item-details">${escapeHTML(details)}</div>` : "";
}
async function render() {
  const items = await getAll();
  $("allCount").textContent = items.filter(i => !i.completed).length;
  $("pageTitle").textContent = labels[activeFilter] || labels.inbox;
  const query = $("searchInput").value.trim().toLowerCase();
  let filtered = items.filter(item => {
    if (activeFilter === "today" && (!item.dueDate || !isToday(item.dueDate) || item.completed)) return false;
    if (activeFilter === "tasks" && item.type !== "task") return false;
    if (activeFilter === "notes" && item.type !== "note") return false;
    if (activeFilter === "links" && item.type !== "link") return false;
    if (activeFilter === "completed" && !item.completed) return false;
    if (activeFilter === "inbox" && item.completed) return false;
    return `${item.title} ${item.details || ""}`.toLowerCase().includes(query);
  });
  $("resultCount").textContent = `${filtered.length} item${filtered.length === 1 ? "" : "s"}`;
  $("emptyState").classList.toggle("hidden", filtered.length > 0);
  $("itemsList").innerHTML = filtered.map(item => {
    const due = item.dueDate ? `<span class="tag ${item.dueDate < new Date().toLocaleDateString("en-CA") && !item.completed ? "overdue" : "due"}">${item.dueDate < new Date().toLocaleDateString("en-CA") && !item.completed ? "Overdue · " : "Due · "}${escapeHTML(formatDate(item.dueDate))}</span>` : "";
    return `<article class="item ${item.completed ? "completed" : ""}">
      <input class="check" type="checkbox" aria-label="Mark ${escapeHTML(item.title)} complete" data-action="complete" data-id="${escapeHTML(item.id)}" ${item.completed ? "checked" : ""}>
      <div class="item-main"><div class="item-title">${escapeHTML(item.title)}</div>${renderDetails(item)}<div class="meta"><span class="tag">${escapeHTML(item.type === "link" ? "Saved link" : item.type[0].toUpperCase()+item.type.slice(1))}</span>${due}</div></div>
      <div class="item-actions"><button class="icon-button" data-action="edit" data-id="${escapeHTML(item.id)}" aria-label="Edit item">Edit</button></div>
    </article>`;
  }).join("");
}
async function safeRender() {
  try { await render(); $("saveStatus").textContent = "Saved on this device"; }
  catch (error) { console.error(error); $("saveStatus").textContent = "Storage problem"; toast("Couldn't read local data. Export/restore if you have a backup."); }
}
$("addForm").addEventListener("submit", async event => {
  event.preventDefault();
  const title = $("itemTitle").value.trim();
  if (!title) return;
  const item = { id: makeId(), title, type: $("itemType").value, dueDate: $("itemDate").value || "", details: $("itemDetails").value.trim(), completed: false, createdAt: Date.now(), updatedAt: Date.now() };
  try {
    await put(item);
    $("itemTitle").value = ""; $("itemDate").value = ""; $("itemDetails").value = ""; $("itemType").value = "task";
    await safeRender(); $("itemTitle").focus(); toast("Added to DayNest");
  } catch (error) { console.error(error); toast("Couldn't save. Check available device storage."); }
});
document.querySelectorAll(".nav").forEach(button => button.addEventListener("click", () => {
  activeFilter = button.dataset.filter;
  document.querySelectorAll(".nav").forEach(b => b.classList.toggle("active", b === button));
  safeRender();
}));
$("searchInput").addEventListener("input", safeRender);
$("itemsList").addEventListener("change", async event => {
  const input = event.target.closest('[data-action="complete"]');
  if (!input) return;
  try {
    const item = (await getAll()).find(i => i.id === input.dataset.id);
    if (!item) return;
    item.completed = input.checked; item.updatedAt = Date.now();
    await put(item); await safeRender();
  } catch (error) { console.error(error); toast("Couldn't update this item."); }
});
$("itemsList").addEventListener("click", async event => {
  const button = event.target.closest('[data-action="edit"]');
  if (!button) return;
  const item = (await getAll()).find(i => i.id === button.dataset.id);
  if (!item) return;
  $("editId").value = item.id; $("editTitle").value = item.title; $("editType").value = item.type;
  $("editDate").value = item.dueDate || ""; $("editDetails").value = item.details || "";
  $("editDialog").showModal();
});
function closeDialog() { $("editDialog").close(); }
$("closeDialog").addEventListener("click", closeDialog);
$("cancelEdit").addEventListener("click", closeDialog);
$("editForm").addEventListener("submit", async event => {
  event.preventDefault();
  const items = await getAll(); const item = items.find(i => i.id === $("editId").value);
  if (!item) return closeDialog();
  item.title = $("editTitle").value.trim(); item.type = $("editType").value; item.dueDate = $("editDate").value || "";
  item.details = $("editDetails").value.trim(); item.updatedAt = Date.now();
  if (!item.title) return;
  try { await put(item); closeDialog(); await safeRender(); toast("Changes saved"); } catch (error) { console.error(error); toast("Couldn't save changes."); }
});
$("deleteBtn").addEventListener("click", async () => {
  const id = $("editId").value;
  if (!confirm("Delete this item? This cannot be undone unless you have a backup.")) return;
  try { await remove(id); closeDialog(); await safeRender(); toast("Item deleted"); } catch (error) { console.error(error); toast("Couldn't delete this item."); }
});
$("exportBtn").addEventListener("click", async () => {
  try {
    const payload = { app: "DayNest", schemaVersion: 1, exportedAt: new Date().toISOString(), items: await getAll() };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = `daynest-backup-${new Date().toISOString().slice(0,10)}.json`; a.click();
    URL.revokeObjectURL(url); toast("Backup exported");
  } catch (error) { console.error(error); toast("Couldn't export backup."); }
});
$("importInput").addEventListener("change", async event => {
  const file = event.target.files?.[0]; if (!file) return;
  try {
    const payload = JSON.parse(await file.text());
    if (!payload || payload.app !== "DayNest" || !Array.isArray(payload.items) || payload.items.length > 10000) throw new Error("Invalid backup format");
    const valid = payload.items.every(i => i && typeof i.id === "string" && typeof i.title === "string" && ["task","note","link"].includes(i.type));
    if (!valid) throw new Error("Invalid item");
    if (!confirm(`Import ${payload.items.length} items? Items with matching IDs will be replaced; other items will remain.`)) return;
    for (const item of payload.items) await put({ ...item, updatedAt: Number(item.updatedAt) || Date.now() });
    await safeRender(); toast("Backup imported");
  } catch (error) { console.error(error); alert("This file doesn't look like a valid DayNest backup."); }
  finally { event.target.value = ""; }
});
window.addEventListener("beforeinstallprompt", event => { event.preventDefault(); deferredInstallPrompt = event; $("installBtn").classList.remove("hidden"); });
$("installBtn").addEventListener("click", async () => {
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt(); await deferredInstallPrompt.userChoice; deferredInstallPrompt = null; $("installBtn").classList.add("hidden");
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(err => console.warn("Offline support registration failed", err)));
}
(async () => {
  try { db = await openDB(); await safeRender(); }
  catch (error) { console.error(error); $("saveStatus").textContent = "Storage unavailable"; toast("DayNest couldn't open local storage in this browser."); }
})();
